### Install Dependencies
pip install -r requirements.txt


### Set Up Environment Variables
OPENAI_API_KEY=your_openai_api_key
PINECONE_API_KEY=your_pinecone_api_key

### Run the application
streamlit run education_chatbot.py

